<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Bienvenido</h1>

    <a class="login"href="login.php">Iniciar sesión</a>
  </div>
  <div class="mantenimiento"> 
    <h1>Página en Prueba 👨 🔧</h1>
   <p>Estamos realizando labores de prueba en este momento. Disculpa las molestias. </p>
    <p>Puedes ingresar dando click en el botón de <a href="login.php"> Iniciar Sesión</a></p>
    <p> Eres nuevo? <a href="registro.php"> Registrate</a></p>

</body>
  <footer>
    <div class="informacion-footer">
      <p>&copy; 2024 Sebastián Saavedra. Todos los derechos reservados.</p>

    </div>
  </footer>
</html>
